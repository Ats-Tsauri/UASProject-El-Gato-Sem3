using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    public Rigidbody2D _rb;
    public InputAction _playerController;
    public float _moveSpeed = 5f;
    public AudioSource _sound;

    public int health;
    public int numOfHeart;
    public string Gameover = "GameOver1";

    public Image[] hearts;
    public Sprite fullHeart;
    public Sprite emptyHeart;

    public Text timerText;
    public float countdownTime = 60.0f;

    public float delayMati = 2.0f;

    Vector2 _moveDirection = Vector2.zero;

    private void OnEnable()
    {
        _playerController.Enable();
    }

    private void OnDisable()
    {
        _playerController.Disable();
    }

    // Start is called before the first frame update
    private void Awake()
    {
        _rb = GetComponent<Rigidbody2D>();

    }

    // Update is called once per frame
    void Update()
    {
        _moveDirection = _playerController.ReadValue<Vector2>();

        if (health > numOfHeart)
        {
            health = numOfHeart;
        }

        for (int i = 0; i < hearts.Length; i++)
        {
            if (i < health)
            {
                hearts[i].sprite = fullHeart;
            }
            else
            {
                hearts[i].sprite = emptyHeart;
            }

            if (i < numOfHeart)
            {
                hearts[i].enabled = true;
            }
            else
            {
                hearts[i].enabled = false;
            }
        }
    }

    private void FixedUpdate()
    {
        _rb.velocity = new Vector2(_moveDirection.x * _moveSpeed, _moveDirection.y * _moveSpeed);
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Obstacle"))
        {
            Debug.Log("Objek tertentu telah memasuki trigger.");
            SoundPlay();
            takeDamage(1);
        }
    }

    public void SoundPlay()
    {
        _sound.Play();
    }

    public void takeDamage(int damage)
    {
        health -= damage;
        if (health <= 0)
        {
            Die();
        }
    }

    public void Die()
    {
        StartCoroutine(DelayedDestroy());
    }

    private void Start()
    {
        // Mulai countdown ketika scene dimuat
        StartCoroutine(StartCountdown());
    }

    private IEnumerator StartCountdown()
    {
        float timeRemaining = countdownTime;

        while (timeRemaining > 0)
        {
            // Perbarui teks waktu
            timerText.text = "Countdown: " + Mathf.Ceil(timeRemaining).ToString();

            // Kurangi waktu
            timeRemaining -= Time.deltaTime;

            yield return null;
        }

        // Countdown selesai, lakukan sesuatu di sini (misalnya, mengganti scene)
        timerText.text = "Countdown: 0";
        Win();
        // Ganti scene atau lakukan aksi lainnya
        // Misalnya: SceneManager.LoadScene("NextLevelScene");
    }

    private IEnumerator DelayedDestroy()
    {
        // Tunggu selama delayTime
        yield return new WaitForSeconds(delayMati);

        // Setelah penundaan, hancurkan objek
        Destroy(gameObject);
        Lose();
    }
    public void Lose()
    {
        SceneManager.LoadScene("Gameover");
    }
    public void Win()
    {
        SceneManager.LoadScene("Menang");
    }
}
