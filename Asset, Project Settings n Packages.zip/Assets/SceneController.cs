using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneController : MonoBehaviour
{
    // Start is called before the first frame update
    public void Normal()
    {
        SceneManager.LoadScene("Gameplay");
    }
    public void Hard()
    {
        SceneManager.LoadScene("Hard");
    }
    public void Gameover()
    {
        SceneManager.LoadScene("GameOver");
    }
    public void Gameover1()
    {
        SceneManager.LoadScene("GameOver1");
    }
    public void Menu()
    {
        SceneManager.LoadScene("Menu");
    }
    public void Menang()
    {
        SceneManager.LoadScene("Menang");
    }
    public void Menang1()
    {
        SceneManager.LoadScene("Menang1");
    }
    public void Quit()
    {
        Application.Quit();
    }
}
